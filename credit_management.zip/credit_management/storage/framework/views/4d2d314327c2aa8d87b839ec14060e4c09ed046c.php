<!DOCTYPE html>
<html>
<head>
	<title>Credit Management</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	
</head>
<body>
	<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Credit Management</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="/">Home</a></li>
      <li><a href="add_user">Add User</a></li>
      <li><a href="transfer_history">Transfer History</a></li>
    </ul>
    
  </div>
</nav>
<table class="table table-dark table-striped" style="font-size: 15px;">
  <tr>
    <th>SL </th>
    <th>User Name</th>
    <th>Email Id </th>
    <th>Credit</th>
    <th>Action</th>
  </tr>
  <?php $i=1; ?>
  <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($i); ?></td>
    <td><?php echo e($row->username); ?> </td>
    <td><?php echo e($row->email); ?> </td>
    <td><?php echo e($row->credit); ?></td>
    <td>
         
         <a href="<?php echo e(URL::to('view/user/'.$row->id)); ?>" class="btn btn-sm btn-info" >View</a>
           
         <a href="<?php echo e(URL::to('delete/user/'.$row->id)); ?>" class="btn btn-sm btn-success">Delete</a>
    </td>
  </tr>
  <?php $i++; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

</body>
</html>

  <?php /**PATH C:\laragon\www\credit_management\resources\views/user/viewall_user.blade.php ENDPATH**/ ?>