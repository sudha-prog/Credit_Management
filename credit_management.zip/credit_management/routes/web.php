<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});

Route::get('add_user','user_controller@user')->name('add_user');
//user are here
Route::post('store.user','user_controller@storeuser')->name('store.user');
Route::get('viewall_user','user_controller@viewalluser')->name('viewall_user');
Route::get('view/user/{id}','user_controller@viewuser');
Route::get('delete/user/{id}','user_controller@deleteuser');
Route::get('transfercredit','user_controller@transfer')->name('transfercredit');

Route::post('get_username','user_controller@get_username');
Route::post('credit.transfer','user_controller@credittransfer')->name('credit.transfer');
Route::get('transfer_history','user_controller@transferhistory')->name('transfer_history');

