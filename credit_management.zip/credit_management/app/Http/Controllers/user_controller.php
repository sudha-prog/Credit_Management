<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class user_controller extends Controller
{
	public function user()
	{
		return view('user.add_user');
	}
	public function transfer()
	{
		return view('user.transfercredit');
	}
   public function storeuser(Request $request)
	{
		$validatedData = $request->validate([
    'user' => ['required', 'unique:credit_managemnt,username', 'max:25','min:4'],
    'email' => ['required', 'unique:credit_managemnt,email', 'max:255'],
    'credit'=>['required', 'unique:credit_managemnt,credit', 'max:45',],
]);
		$data=array();
		$data['username']=$request->user;
		$data['email']=$request->email;
		$data['credit']=$request->credit;
		$user=DB::table('credit_managemnt')->insert($data);
		if($user){
			$notification=array(
				'messege'=>'Successfully Done',
				'alert-type'=>'success'
			);
			return Redirect()->back()->with($notification);

			

		}else{
			$notification=array(
				'messege'=>'something error',
				'alert-type'=>'error'
			);
			return Redirect()->back()->with($notification);

		}


	}
	public function viewalluser(){
		$user=DB::table('credit_managemnt')->get();
		//return response()->json($user);
		return view('user.viewall_user',compact('user'));
		//return view('user.viewall_user',with('');
	}
	public function viewuser($id){

          $user=DB::table('credit_managemnt')->where('id',$id)->first();
          return view('user.view_user')->with('cat',$user);

	}
	public function deleteuser($id){

          $delete=DB::table('credit_managemnt')->where('id',$id)->delete();

          return Redirect()->back();

	}

	public function get_username(Request $request){

		 $statusCode = 200;
            if (!$request->ajax()) {

              $statusCode = 400;
              $response = array('error' => 'Error occered in Json call.');
              return response()->json($response, $statusCode);
            }
            try {

              $tbl_blockmunu_master = DB::table('credit_managemnt')->pluck('username', 'id');


              $response = array(
                'options' => $tbl_blockmunu_master, 'status' => 1
              );
            }
            catch (\Exception $e) {
              $response = array(
                'exception' => true,
                'exception_message' => $e->getMessage(),
              );
              $statusCode = 400;
            } finally {
              return response()->json($response, $statusCode);
            }


	}
	 public function credittransfer(Request $request)
	{
		$validatedData = $request->validate([
    'tns_from' => ['required'],
    'tns_to' => ['required'],
    'credit'=>['required'],
]);
		$data=array();
		$data['transfer_from']=$request->tns_from;
		$data['transfer_to']=$request->tns_to;
		$data['credit']=$request->credit;
		$user=DB::table('transfer_credit')->insert($data);

		$current_credit_transfer_to=DB::table('credit_managemnt')->where('id',$request->tns_to)->select('credit')->first();

		$current_credit_transfer_from=DB::table('credit_managemnt')->where('id',$request->tns_from)->select('credit')->first();
		$credit_now_to=(int)$current_credit_transfer_to->credit + (int)$request->credit;
		$credit_now_from=(int)$current_credit_transfer_from->credit - (int)$request->credit;

		$result=DB::table('credit_managemnt')->where('id',$request->tns_to)->update(['credit'=>$credit_now_to]);

		$result=DB::table('credit_managemnt')->where('id',$request->tns_from)->update(['credit'=>$credit_now_from]);

		if($user){
			return view('user.transfercredit')->with('error','Transfer Successfuly')
;
			

		}



	}
		public function transferhistory(){
			 $data=array();
		$history=DB::table('transfer_credit')->get();
             $count=1;
		 foreach ($history as $singledata) {
            $nestedData['id'] = $count;
            
           $result_from=DB::table('credit_managemnt')->where('id',$singledata->transfer_from)->select('username')->first();
           $result_to=DB::table('credit_managemnt')->where('id',$singledata->transfer_to)->select('username')->first();
             $nestedData['result_from'] = $result_from->username;
              $nestedData['result_to'] = $result_to->username;
              $nestedData['credit'] = $singledata->credit;

            $count++;
            $data[] = $nestedData;
        }
        // echo  $data['id']
		//return response()->json($user);
		return view('user.transfer_history')->with('tnshistory',$data);
		//return view('user.viewall_user',with('');
	}
}
