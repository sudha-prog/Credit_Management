<!DOCTYPE html>
<html>
<head>
	<title>Credit Management</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

	
</head>
<body>
	<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#" style="font-size: 15px;">Credit Management</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="/" style="font-size: 15px;">Home</a></li>
      <li><a href="add_user" style="font-size: 15px;">Add User</a></li>
      <li><a href="transfer_history" style="font-size: 15px;" >Transfer History</a></li>
    </ul>
    
  </div>
</nav>
<section class="my-5">
    <div class="py-5">
      <h3 class="text-center" style="font-family: 'Dancing Script', cursive; font-size: 80px; color:#cc6600;" ><b>Transfer Credit</b></h3>
    </div>
            <div class="w-50 m-auto">
            <?php           
if (isset($error)) { ?>
   <div class="alert alert-danger">
        <ul>
          <?php echo $error;?>
        </ul>
    </div>
<?php } ?>
              {!! Form::open(['url' => 'credit.transfer', 'method' => 'post' ,'name' => 'credit_transfer', 'id'=>'credit_transfer' , 'class'=>'animate-form form-horizontal']) !!}
                 {!! Form::hidden('code',"",['id'=>'code']) !!}
                                
                               
               
                <div class="form-group">
                   
                        {!! Form::label('tns_from',"Transfer From",['class'=>'col-sm-4 col-sm-offset-1 col-form-label required']) !!}
                         <div class="col-sm-6">
                         {!! Form::select('tns_from',[''=>'--- Select User ---'],null,['id'=>'tns_from','class'=>'form-control','autocomplete'=>'off']) !!}
                     </div>
                     
                </div>
                <div class="form-group">
                   
                        {!! Form::label('tns_to',"Transfer To",['class'=>'col-sm-4 col-sm-offset-1 col-form-label required']) !!}
                         <div class="col-sm-6">
                         {!! Form::select('tns_to',[''=>'--- Select User ---'],null,['id'=>'tns_to','class'=>'form-control','autocomplete'=>'off']) !!}
                     </div>
                     
                </div>
                <div class="form-group">
                   
                        {!! Form::label('credit',"credit",['class'=>'col-sm-4 col-sm-offset-1 col-form-label required']) !!}
                         <div class="col-sm-6">
                         {!! Form::text('credit',null,['class' => 'form-control','id'=>'credit', 'placeholder' => 'credit','autocomplete'=>'off']) !!}
                     </div>
                     
                </div>
                 
                <div class="row form-group">
                    <div class="col-sm-3 text-center col-sm-offset-6">
                        {!! Form::submit('Submit',['class' => 'btn btn-success btn-block','type'=>'submit','id'=>'submit']) !!}
                    </div>
                </div>
                
                {!! Form::close() !!}

            </div>


    </section>
    <script>

    	$(document).ready(function(){
		 get_user();
		});



    	function get_user() {
    var token = $("input[name='_token']").val();
    
    $.ajax({
      type: "post",
      url: "get_username",
      data:{_token:token},
      dataType: 'json',
      success: function (data) {
      
        $('#tns_to').html('<option value=""> Select user </option>');
         $('#tns_from').html('<option value=""> Select user </option>');

        $.each(data.options, function (key, value) {
        
            $("#tns_to").append('<option value=' + key + '>' + value + '</option>');
             $("#tns_from").append('<option value=' + key + '>' + value + '</option>');
          

        });
      }

    });
  }
    </script>
</body>

</html>