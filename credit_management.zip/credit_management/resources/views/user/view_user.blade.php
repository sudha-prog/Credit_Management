<!DOCTYPE html>
<html>
<head>
	<title>Credit Management</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.css">
	
</head>
<body>
	<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#" style="font-size: 15px;">Credit Management</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="/" style="font-size: 15px;">Home</a></li>
      <li><a href="add_user" style="font-size: 15px;">Add User</a></li>
      <li><a href="transfer_history" style="font-size: 15px;">Transfer History</a></li>
    </ul>
    
  </div>
</nav>
<div >
  <table class="table table-dark">
 
  <tr>
    <td style="font-size: 15px; font-family: Arial, Helvetica, sans-serif;">Name : {{$cat->username}}</td>
    <td style="font-size: 15px;font-family: Arial, Helvetica, sans-serif;">Email Id : {{$cat->email}}</td>
    <td style="font-size: 15px;font-family: Arial, Helvetica, sans-serif;">Credit Point : {{$cat->credit}}</td>
       
  </tr>
</table>

</div>