<!DOCTYPE html>
<html>
<head>
	<title>Credit Management</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.css">
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<style type="text/css">
  .social{
      width: 20px;
      height: 20px;
      float: right;
      display: flex;
      border-radius: 30%;
      margin-right: 0.4rem;

      padding: 0.09rem;
    }
  .social a{
      width: 100px;
      height: 20px;
      float: right;
      display: flex;
    }
</style>
	
</head>
<body>
	<section>
	<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#" style="font-size: 15px;">Credit Management</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="/" style="font-size: 15px;">Home</a></li>
      <li><a href="add_user" style="font-size: 15px;">Add User</a></li>
       <li><a href="transfer_history" style="font-size: 15px;">Transfer History</a></li>
    </ul>
    <p class="p-2 bg-dark text-white text-center" style="font-size: 15px">@Created by Sudha Rani Mondal</p>
   
      
      <a href="https://www.linkedin.com/in/sudha-rani-mondal-943a40183"><img src="images/link.png" class="social"></a>
        <a href="https://github.com/sudha-prog"><img src="images/git.png" class="social"></a>
          
       
   
  </div>
</nav>
<section class="my-5">
		<div class="py-5">
<div class="col-lg-4 col-md-4 col-12">
					<div class="card" >
  			<img class="card-img-top" src="images/user.jpg" alt="Ilish Vapa"  class="img-fluid pb-3" width="50px" height="250px">
  						<div class="card-body">
    					<h4 class="card-title" style="font-size: 15px;">View All User</h4>
   						
   						<!--button-->
    						<a href="viewall_user" class="btn btn-dark" style="font-size: 15px;">Click Here</a>
  						</div>
					</div>
			
				</div>
				<!--Chicken Tikka-->
				<div class="col-lg-4 col-md-4 col-12">
					<div class="card" >
  			<img class="card-img-top" src="images/transfer.png" alt="Chicken Tikka"  class="img-fluid pb-3" width="50px" height="250px">
  						<div class="card-body">
    					<h4 class="card-title" style="font-size: 15px;">Transfer Credit</h4>
   					
   						<!--button-->
    						<a href="transfercredit" class="btn btn-dark" style="font-size: 15px;">Click Here</a>
  						</div>
					</div>
			
				</div>
				<!--Chicken Kabiraji-->
				<div class="col-lg-4 col-md-4 col-12">
					<div class="card" >
  			<img class="card-img-top" src="images/history.png" alt="Chicken Kabiraji"  class="img-fluid pb-3" width="50px" height="250px">
  						<div class="card-body">
    					<h4 class="card-title" style="font-size: 15px;">Transfer History</h4>
   						
   						<!--button-->
    						<a href="transfer_history" class="btn btn-dark" style="font-size: 15px;">Click Here</a>
  						</div>
					</div>
			
				</div>
        </div>
       
<!--
<section>
<div class="section">
	<div class="container">
		
		
		<div >
		<div class="box">
			<div class="icon">
				<i class="fa fa-user" aria-hidden="true"></i>
			</div>
			<div class="content">
				<button class="button"><a class="btn btn-basic" href="viewall_user">View All User</a></button>
			</div>
		</div>
	</div>
	<div >
		<div class="box">
			<div class="icon">
			<i class="fa fa-exchange" aria-hidden="true"></i>
			</div>
			<div class="content">
				<button class="button"><a class="btn btn-dark navbar-btn" href="transfercredit">Transfer Credit</a></button>
			</div>
		</div>
	</div>
	<div >
		<div class="box">
			<div class="icon">
				<i class="fa fa-history" aria-hidden="true"></i>
			</div>
			<div class="content">
				<button class="button"><a class="btn btn-dark navbar-btn" href="transfer_history" class="img-fluid pb-3">Transfer History</a></button>
			</div>
		</div>
	</div>
	</div>

</div>-->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script>
@if(Session::has('messege'))
var type="{{Session::get('alert-type','info')}}"
switch(type){
	case 'info':
	toastr.info("{{Session::get('messege')}}");
	break;
	case 'success':
	toastr.success("{{Session::get('messege')}}");
	break;
	case 'warning':
	toastr.warning("{{Session::get('messege')}}");
	break;
	case 'error':
	toastr.error("{{Session::get('messege')}}");
	break;
}
@endif
</script>
</div>
</section>
</section>


</body>
</html>